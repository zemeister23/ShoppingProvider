enum PreferenceKeys { TOKEN }
