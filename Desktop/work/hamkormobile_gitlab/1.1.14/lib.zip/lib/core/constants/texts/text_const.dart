class TextConst {
  // * USE MAGIC NUMBER METHOD FOR CONST TEXT
  static const String TITLE_APP = "Hamkormobile";
}
