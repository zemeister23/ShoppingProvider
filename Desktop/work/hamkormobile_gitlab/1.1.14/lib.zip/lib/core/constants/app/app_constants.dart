class ApplicationConstants {
  static const LANG_ASSET_PATH = "assets/lang";
}
