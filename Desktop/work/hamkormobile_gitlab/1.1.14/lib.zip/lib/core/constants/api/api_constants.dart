class ApiConst {
  // TODO: Type Base Url Here
  static const BASE_URL = "https://blahblah.com";
}
