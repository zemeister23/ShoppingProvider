import 'package:flutter/material.dart';

abstract class AppTheme {
  ThemeData light = ThemeData();
  ThemeData dark = ThemeData();
}
