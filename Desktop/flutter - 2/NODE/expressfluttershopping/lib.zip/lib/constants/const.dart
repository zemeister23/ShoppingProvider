import 'dart:io';

String ipAdress =
    Platform.isAndroid ? "http://10.0.2.2:3000" : "http://localhost:3000";
