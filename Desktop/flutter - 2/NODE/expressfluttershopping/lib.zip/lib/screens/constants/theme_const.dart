import 'package:flutter/material.dart';

class ThemeConst {
  static ThemeData mainTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.yellow,
  );
}
